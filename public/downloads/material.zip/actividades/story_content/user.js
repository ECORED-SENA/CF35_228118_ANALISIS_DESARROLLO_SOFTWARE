function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5rlIRaG8ncN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

